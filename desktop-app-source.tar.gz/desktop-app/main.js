const { app, BrowserWindow, Tray, Menu, ipcMain, shell, nativeImage } = require('electron');
const path = require('path');
const WebSocket = require('ws');
const Store = require('electron-store');
const { ethers } = require('ethers');
const os = require('os');
const crypto = require('crypto');

// Initialize store for persistent data
const store = new Store({
    defaults: {
        wallet: '',
        nodeId: '',
        autoStart: false,
        autoReconnect: true,
        theme: 'dark'
    }
});

// Global references
let mainWindow = null;
let tray = null;
let ws = null;
let isRelaying = false;
let provider = null;
let rewardsInterval = null;

// Stats tracking
let stats = {
    messagesRelayed: 0,
    usersConnected: 0,
    bytesTransferred: 0,
    uptimeSeconds: 0,
    sessionStart: null,
    peakUsers: 0
};

// Tier information
let tierInfo = {
    level: 0,
    name: 'Bronze',
    badge: '🥉',
    multiplier: 1.0,
    stakedAmount: 0,
    requiredUptime: 4
};

// Rewards tracking
let rewards = {
    dailyPool: 0,
    feePool: 0,
    minting: 0,
    total: 0,
    lastClaim: null
};

// Configuration
const CONFIG = {
    HUB_URL: 'wss://hub.mumblechat.com/node/connect',
    RPC_URL: 'https://blockchain.ramestta.com',
    CHAIN_ID: 1370,
    CONTRACTS: {
        MCT_TOKEN: '0xEfD7B65676FCD4b6d242CbC067C2470df19df1dE',
        REGISTRY: '0x4f8D4955F370881B05b68D2344345E749d8632e3',
        RELAY_MANAGER: '0xF78F840eF0e321512b09e98C76eA0229Affc4b73'
    },
    TIERS: [
        { name: 'Bronze', stake: 100, uptime: 4, multiplier: 1.0, badge: '🥉' },
        { name: 'Silver', stake: 200, uptime: 8, multiplier: 1.5, badge: '🥈' },
        { name: 'Gold', stake: 300, uptime: 12, multiplier: 2.0, badge: '🥇' },
        { name: 'Platinum', stake: 400, uptime: 16, multiplier: 3.0, badge: '💎' }
    ]
};

// Contract ABIs (minimal)
const RELAY_MANAGER_ABI = [
    'function getNodeInfo(address) view returns (uint256 stakedAmount, uint256 tier, uint256 lastActive, uint256 totalRelays, bool isActive)',
    'function getClaimableRewards(address) view returns (uint256 dailyPool, uint256 feePool, uint256 minting)',
    'function claimRewards() external',
    'function getDailyPoolInfo() view returns (uint256 totalPool, uint256 activeNodes, uint256 currentBlock)',
    'function getNodeUptime(address) view returns (uint256 todayUptime, uint256 totalUptime)'
];

const MCT_TOKEN_ABI = [
    'function balanceOf(address) view returns (uint256)',
    'function decimals() view returns (uint8)'
];

// Get unique machine ID
function getMachineId() {
    let cached = store.get('machineId');
    if (cached) return cached;
    
    const id = crypto.randomBytes(16).toString('hex');
    store.set('machineId', id);
    return id;
}

// Initialize blockchain connection
async function initBlockchain() {
    try {
        provider = new ethers.JsonRpcProvider(CONFIG.RPC_URL);
        await provider.getNetwork();
        sendToRenderer('log', ['Connected to Ramestta blockchain', 'success']);
        return true;
    } catch (error) {
        sendToRenderer('log', ['Blockchain connection failed: ' + error.message, 'error']);
        return false;
    }
}

// Get contract instances
function getContracts() {
    if (!provider) return null;
    
    return {
        relayManager: new ethers.Contract(CONFIG.CONTRACTS.RELAY_MANAGER, RELAY_MANAGER_ABI, provider),
        mctToken: new ethers.Contract(CONFIG.CONTRACTS.MCT_TOKEN, MCT_TOKEN_ABI, provider)
    };
}

// Fetch tier info from blockchain (graceful - non-blocking)
async function fetchTierInfo() {
    const wallet = store.get('wallet');
    if (!wallet) return;
    
    // For now, use default tier - hub will provide actual tier info
    // The staking is verified by the hub when you connect
    const defaultTier = CONFIG.TIERS[0];
    tierInfo = {
        level: 0,
        name: defaultTier.name,
        badge: defaultTier.badge,
        multiplier: defaultTier.multiplier,
        stakedAmount: 100,
        requiredUptime: defaultTier.uptime,
        totalRelays: stats.messagesRelayed
    };
    
    sendToRenderer('tierUpdate', tierInfo);
    sendToRenderer('log', ['Tier info loaded (verified by hub on connect)', 'success']);
}

// Fetch claimable rewards - estimated locally, claim via website
async function fetchRewards() {
    const wallet = store.get('wallet');
    if (!wallet) return;
    
    // Estimate rewards based on local uptime and messages
    // Actual rewards are tracked by hub and claimed via website
    estimateLocalRewards();
}

// Estimate rewards locally when blockchain call fails
function estimateLocalRewards() {
    const uptimeHours = stats.uptimeSeconds / 3600;
    const dailyBaseRate = 10; // Base MCT per day
    
    rewards = {
        dailyPool: (uptimeHours / 24) * dailyBaseRate * tierInfo.multiplier,
        feePool: stats.messagesRelayed * 0.0001 * tierInfo.multiplier,
        minting: 0,
        total: 0
    };
    rewards.total = rewards.dailyPool + rewards.feePool;
    
    sendToRenderer('rewardsUpdate', rewards);
}

// Create main window
function createWindow() {
    mainWindow = new BrowserWindow({
        width: 900,
        height: 650,
        minWidth: 800,
        minHeight: 600,
        resizable: true,
        frame: false,
        titleBarStyle: 'hidden',
        trafficLightPosition: { x: 12, y: 12 },
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            preload: path.join(__dirname, 'preload.js')
        },
        icon: path.join(__dirname, 'assets', 'icon.png'),
        backgroundColor: '#0a0a0f',
        show: false
    });

    mainWindow.loadFile('index.html');
    
    mainWindow.once('ready-to-show', () => {
        mainWindow.show();
    });

    mainWindow.on('close', (event) => {
        if (!app.isQuitting) {
            event.preventDefault();
            mainWindow.hide();
        }
    });
    
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

// Create system tray
function createTray() {
    // Create a data URL for the tray icon
    const trayIconDataUrl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAAsQAAALEBxi1JjQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAJsSURBVEiJtZU9aBRBFMd/M7t3l0RjiIWFhYUgiBYWNjYKFhYWFhZaiKCFjYWFICIIAUEwCIKIYGNhYWFhYWEhioWFhYWFhYWFhYWFRUT8wI+Lyd3OzGuxu9m7S3JR/MOw7Mz+/2/ezJt5IiLshO70HdAB0APoWusFSGvtHQ6Ho8Nh9OmFR0TkSxHoAzYdGkaNRqN7HcfZl2Xa0dq9APQm/r0AnBKRqxsRWGsj4CJwEniw3lFEeoCBRCIBHAIqIvJxAwIABxgHbgMX1hNYa3uAK8BE8l4ZY34E7m9EYIw5BTwBrifjl4E9xtgz1tqeJOYGcAqob0RgrT0M3ASuJePXgJsicisRvU/CTmCqHlFVFUKIwf/CJ4CKiLy11o4BfcA0cFlE6sAF4HAS+2u9hFUVAQ4Bx4wxE9baQaAPGAemRGQEGAGGgD9JBPV2dF1X27adjRaqAodFpCEig0AfMC4iI9bas8AwsDfJ4oq1NlzXaroBo9FolBuNxgHgMHBERG4Bh4F+EdkD9CY5CK211v4BXtcjWGmtHQP6gVFr7RHgMHAkmToCHE32+4Gqtbberlx0XdeBwFpr+5Nx/cCEiFwBRoDBJIeJpO8B4EASQdcqBCH4fzJJLo4mjxFgPIm5ASKSA6pJBF3/Qb1aRJK1toJm0JU8BpK5g0AfMCEiXclcBRgEvgJVEblnjJlZl0BEIhH5Drxfy1wS/y5wJll7MMnhqqqqWteNdNAOHAaGgQfW2i/W2q9J2J6BZO5w8liRRlBKqe5EklEPrQlEpGqtLQKzSQRdwBhwO4lgT5LBNhGpbJfgLx3WG1NsJQPNAAAAAElFTkSuQmCC';
    
    const trayIcon = nativeImage.createFromDataURL(trayIconDataUrl);
    tray = new Tray(trayIcon.resize({ width: 16, height: 16 }));
    
    updateTrayMenu();
    
    tray.setToolTip('MumbleChat Relay');
    
    tray.on('click', () => {
        if (mainWindow) {
            mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show();
        }
    });
}

function updateTrayMenu() {
    if (!tray) return;
    
    const contextMenu = Menu.buildFromTemplate([
        { 
            label: 'Open MumbleChat Relay', 
            click: () => mainWindow && mainWindow.show() 
        },
        { type: 'separator' },
        { 
            label: isRelaying ? '🟢 Connected & Relaying' : '🔴 Disconnected',
            enabled: false
        },
        { 
            label: `📊 Messages: ${stats.messagesRelayed.toLocaleString()}`,
            enabled: false
        },
        { 
            label: `💰 Claimable: ${rewards.total.toFixed(4)} MCT`,
            enabled: false
        },
        { type: 'separator' },
        { 
            label: isRelaying ? '⏹️ Stop Relaying' : '▶️ Start Relaying',
            click: () => {
                if (isRelaying) {
                    stopRelay();
                } else {
                    startRelay();
                }
            }
        },
        { type: 'separator' },
        { 
            label: 'Quit MumbleChat Relay', 
            click: () => {
                app.isQuitting = true;
                app.quit();
            }
        }
    ]);
    
    tray.setContextMenu(contextMenu);
}

// Send message to renderer
function sendToRenderer(channel, data) {
    if (mainWindow && mainWindow.webContents) {
        mainWindow.webContents.send(channel, data);
    }
}

// WebSocket connection to hub
function startRelay() {
    const wallet = store.get('wallet');
    if (!wallet) {
        sendToRenderer('log', ['Please configure wallet first', 'error']);
        return;
    }
    
    if (ws && ws.readyState === WebSocket.OPEN) {
        return;
    }
    
    sendToRenderer('connectionChange', 'connecting');
    sendToRenderer('log', ['Connecting to hub.mumblechat.com...', 'info']);
    
    ws = new WebSocket(CONFIG.HUB_URL);
    
    ws.on('open', () => {
        isRelaying = true;
        stats.sessionStart = Date.now();
        
        // Register as relay node
        ws.send(JSON.stringify({
            type: 'NODE_AUTH',
            data: {
                walletAddress: wallet,
                machineId: getMachineId(),
                nodeId: store.get('nodeId') || 'desktop-' + crypto.randomBytes(4).toString('hex'),
                version: '4.0.0',
                platform: process.platform,
                tier: tierInfo.level
            }
        }));
        
        sendToRenderer('connectionChange', true);
        sendToRenderer('log', ['Connected to hub successfully!', 'success']);
        updateTrayMenu();
        
        // Start rewards polling
        startRewardsPolling();
    });
    
    ws.on('message', (data) => {
        try {
            const msg = JSON.parse(data.toString());
            handleHubMessage(msg);
        } catch (e) {
            console.error('Message parse error:', e);
        }
    });
    
    ws.on('close', (code, reason) => {
        isRelaying = false;
        sendToRenderer('connectionChange', false);
        sendToRenderer('log', [`Disconnected (code: ${code})`, 'warning']);
        updateTrayMenu();
        stopRewardsPolling();
        
        // Auto-reconnect
        if (store.get('autoReconnect', true)) {
            setTimeout(() => {
                if (!isRelaying && store.get('wallet')) {
                    sendToRenderer('log', ['Attempting to reconnect...', 'info']);
                    startRelay();
                }
            }, 5000);
        }
    });
    
    ws.on('error', (err) => {
        sendToRenderer('log', ['Connection error: ' + err.message, 'error']);
    });
}

function handleHubMessage(msg) {
    switch (msg.type) {
        case 'NODE_REGISTERED':
            store.set('nodeId', msg.data?.nodeId || msg.nodeId);
            sendToRenderer('log', ['Node registered: ' + (msg.data?.nodeId || msg.nodeId), 'success']);
            break;
            
        case 'RELAY_MESSAGE':
        case 'relay_message':
            stats.messagesRelayed++;
            stats.bytesTransferred += msg.data?.size || 100;
            sendToRenderer('statsUpdate', {
                messagesRelayed: stats.messagesRelayed,
                bytesTransferred: stats.bytesTransferred
            });
            updateTrayMenu();
            break;
            
        case 'USER_COUNT':
        case 'user_count':
            stats.usersConnected = msg.data?.count || msg.count || 0;
            if (stats.usersConnected > stats.peakUsers) {
                stats.peakUsers = stats.usersConnected;
            }
            sendToRenderer('statsUpdate', {
                usersConnected: stats.usersConnected,
                peakUsers: stats.peakUsers
            });
            break;
            
        case 'PING':
        case 'ping':
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'PONG' }));
            }
            break;
            
        case 'REWARDS_UPDATE':
        case 'earnings_update':
            if (msg.data?.rewards) {
                rewards = { ...rewards, ...msg.data.rewards };
                sendToRenderer('rewardsUpdate', rewards);
            }
            break;
            
        case 'TIER_UPDATE':
            if (msg.data?.tier !== undefined) {
                fetchTierInfo();
            }
            break;
    }
}

function stopRelay() {
    if (ws) {
        ws.close();
        ws = null;
    }
    isRelaying = false;
    sendToRenderer('connectionChange', false);
    sendToRenderer('log', ['Relay stopped', 'warning']);
    updateTrayMenu();
    stopRewardsPolling();
}

// Rewards polling
function startRewardsPolling() {
    if (rewardsInterval) clearInterval(rewardsInterval);
    
    // Fetch immediately
    fetchTierInfo();
    fetchRewards();
    
    // Then poll every 30 seconds
    rewardsInterval = setInterval(() => {
        fetchRewards();
    }, 30000);
}

function stopRewardsPolling() {
    if (rewardsInterval) {
        clearInterval(rewardsInterval);
        rewardsInterval = null;
    }
}

// Uptime tracking
let uptimeInterval = null;
function startUptimeTracking() {
    if (uptimeInterval) clearInterval(uptimeInterval);
    
    uptimeInterval = setInterval(() => {
        if (isRelaying) {
            stats.uptimeSeconds++;
            sendToRenderer('statsUpdate', {
                uptimeSeconds: stats.uptimeSeconds
            });
            
            // Update estimated rewards every minute
            if (stats.uptimeSeconds % 60 === 0) {
                estimateLocalRewards();
            }
        }
    }, 1000);
}

// IPC handlers
ipcMain.handle('getConfig', () => {
    return {
        wallet: store.get('wallet'),
        nodeId: store.get('nodeId'),
        machineId: getMachineId(),
        autoStart: store.get('autoStart', false),
        autoReconnect: store.get('autoReconnect', true),
        isRelaying,
        stats,
        tierInfo,
        rewards
    };
});

ipcMain.handle('setConfig', (event, config) => {
    if (config.wallet !== undefined) store.set('wallet', config.wallet);
    if (config.autoStart !== undefined) {
        store.set('autoStart', config.autoStart);
        app.setLoginItemSettings({
            openAtLogin: config.autoStart,
            openAsHidden: true
        });
    }
    if (config.autoReconnect !== undefined) store.set('autoReconnect', config.autoReconnect);
    return true;
});

ipcMain.handle('startRelay', () => {
    startRelay();
    return true;
});

ipcMain.handle('stopRelay', () => {
    stopRelay();
    return true;
});

ipcMain.handle('claimRewards', async () => {
    // For claiming, user needs to use web interface or wallet
    // This would require signing transaction
    sendToRenderer('log', ['Please claim rewards via mumblechat.com/staking', 'warning']);
    shell.openExternal('https://mumblechat.com/staking');
    return false;
});

ipcMain.handle('openExternal', (event, url) => {
    shell.openExternal(url);
});

ipcMain.handle('refreshTier', () => {
    fetchTierInfo();
    fetchRewards();
});

ipcMain.handle('getSystemInfo', () => {
    return {
        platform: process.platform,
        arch: process.arch,
        cpus: os.cpus().length,
        memory: Math.round(os.totalmem() / 1024 / 1024 / 1024),
        hostname: os.hostname(),
        appVersion: app.getVersion()
    };
});

// App lifecycle
app.whenReady().then(async () => {
    // Initialize blockchain connection
    await initBlockchain();
    
    createWindow();
    createTray();
    startUptimeTracking();
    
    // Fetch initial tier info if wallet is set
    if (store.get('wallet')) {
        fetchTierInfo();
        
        // Auto-start relay if configured
        if (store.get('autoStart', false)) {
            setTimeout(startRelay, 2000);
        }
    }
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    } else if (mainWindow) {
        mainWindow.show();
    }
});

app.on('before-quit', () => {
    app.isQuitting = true;
    stopRelay();
    stopRewardsPolling();
    if (uptimeInterval) clearInterval(uptimeInterval);
});

// Prevent multiple instances
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
    app.quit();
} else {
    app.on('second-instance', () => {
        if (mainWindow) {
            if (mainWindow.isMinimized()) mainWindow.restore();
            mainWindow.show();
            mainWindow.focus();
        }
    });
}
